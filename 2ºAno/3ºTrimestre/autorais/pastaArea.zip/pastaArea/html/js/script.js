let d = new Date()
document.body.innerHTML="<h1>A Hora de agora é: "+ d.getHours() + ":"+d.getMinutes() + ":"+d.getSeconds() + "</h1>";
 