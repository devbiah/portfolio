function Duo(){
    const cor = document.getElementById("cor");
        if (cor.style.backgroundColor === "black") {
          cor.style.backgroundColor = "red";
        } else {
          cor.style.backgroundColor = "black";
        }
      }
  